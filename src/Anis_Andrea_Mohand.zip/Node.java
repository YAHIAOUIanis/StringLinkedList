
public class Node {
	 String value;
	 Node next;
	 Node prev;

	public Node(String value, Node prev, Node next) {
		this.value = value;
		this.prev = prev;
		this.next = next;
	}
}
